from django.shortcuts import render
from django.contrib import messages
from process.BooleanModel import BooleanModel
from .forms import QueryForm


def index(request):

    if request.method == "POST":
        form = QueryForm(request.POST)

        if form.is_valid():
            model = BooleanModel("./corpus/*.txt")
            query = form.cleaned_data.get("query")

            result = model.query(query)

            return render(request, "index.html", {"form": form,
                                                  "result": result,
                                                  })
        else:
            print(form.errors())
    else:
        form = QueryForm()
    return render(request, "index.html", {"form": form, "result": {}})
