import glob
import os
import re
from collections import defaultdict
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import numpy as np
import math

from process.query import infix_to_postfix, is_operator
from process.Stack import Stack


class BooleanModel(object):

    def __init__(self, path):
        self.corpus = path
        self.stopwords = stopwords.words("english")
        self.lemmatizer = WordNetLemmatizer()
        self.term_doc = defaultdict(list)
        self.docs = dict()
         # Set of all unique terms in the corpus
        self.vocabulary = set()
    def preprocessing(self):
        index = 1

        # number of words in a document
        doc_word_counter = dict()

        doc_wordfreq = dict()
        
        global tf 
        tf={}

        for file in glob.glob(self.corpus):
            with open(file, 'r') as f:
                text = f.read()

            text = self.remove_special_chars(text)
            text = self.remove_digits(text)
            # Tokenize text into words
            words = word_tokenize(text)

            # Remove stopwords and convert remaining words to lowercase
            words = [word.lower()
                     for word in words if word not in self.stopwords]

            # lematisation
            words = [self.lemmatizer.lemmatize(word) for word in words]
            doc_word_counter[index] = len(words)

            # words occurrences in a document
            words_occ = dict()
            for word in words:
                if index not in self.term_doc[word]:
                    self.term_doc[word].append(index)

                # word occurrences in document
                counter = words.count(word)
                words_occ[word] = counter

            # each document with its terms frequency as a vector
            doc_wordfreq[index] = [words.count(word) for word in words]

            # calculate the term frequency
            tfDict= {}
            for word, occ in words_occ.items():
                result = round(occ / doc_word_counter[index], 5)
                tfDict[word] = result
                
                tf[index] = {}
                for word , tf_count in tfDict.items():
                    tf[index][word] = tf_count                


            # Make a list of indexed docs
            self.docs[index] = os.path.basename(file)

            # Increment count of indexed docs
            index += 1  
            
            # print(self.term_doc)       
        # Make vocabulary out of final postings
        self.vocabulary = self.term_doc.keys()
        return self.term_doc,self.docs ,tf
    
            
    def query(self, query):
        """Query the indexed docs using a boolean model

        :param query: valid boolean expression to search for
        :returns: list of matching document names
        """
        # Tokenize query
        query_tokens = word_tokenize(query)

        # Convert infix query to postfix
        query_tokens = infix_to_postfix(query_tokens)

        # Evaluate query against already processed docs
        matching_docs = self.evaluate_query(query_tokens)

        return matching_docs
    

    def evaluate_query(self, query_tokens):
        """Evaluates the query against the corpus

        :param query_tokens: list of query tokens in postfix form
        :returns: list of matching document names
        """
        operands = Stack()
        
        tf= self.preprocessing()[2]
        docs = self.preprocessing()[1]
        
        indexes = []
        for token in query_tokens:

            # Token is an operator,
            # Pop two elements from stack and apply it.
            if is_operator(token):
                # Pop right operand
                right_operand = operands.pop()

                # Pop left operand
                left_operand = operands.pop()
                
                # Perform operation
                result = self.perform_operation(
                    left_operand, right_operand, token)

                # Push result back into the stack
                operands.push(result)
                

            # Token is an operand, push it to the stack
            else:
                # Lowercasing and stemming query term
                token = self.lemmatizer.lemmatize(token.lower())
                result = []
                for index in docs.keys():
                    for key , value in tf[index].items():
                        if key  == token:
                            indexes.append(index)
                            result.append(value)
                            # Push it's tf value into operand stack
                            for item in result:
                                operands.push(item)            

        rsv_dict = {}
        for index in docs.keys():
            if index in indexes:
                rsv_dict[index] = list(operands.show())
        
        

        # Find out documents corresponding to set bits in the vector
        matching_docs = []
        for index in rsv_dict.keys():
            matching_docs.append(docs[index])
        return [doc for doc in matching_docs]


    def perform_operation(self, left, right, op):
        """Performs specified operation on the vectors

        :param left: left operand
        :param right: right operand
        :param op: operation to perform
        :returns: result of the operation
        """ 

        if op == "&":
            rsv = min(left, right)
            return rsv
        elif op == "|":
            rsv = max(left, right)
            return rsv
        elif op == "~":
            left = 0
            rsv = 1 - right + left
            return rsv
        else:
            return 0

    def remove_special_chars(self, text):
        """Removes special characters from text"""

        # Regex pattern for removing specoal chars
        regex = re.compile(r"[^a-zA-Z0-9\s]")

        # Replace and return
        return re.sub(regex, "", text)

    def remove_digits(self, text):
        """Removes digits from text"""

        # Regex pattern for removing digits
        regex = re.compile(r"\d")

        # Replace and return
        return re.sub(regex, "", text)
    